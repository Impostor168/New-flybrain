# FlyBrainLab Pixel Fly Version

This is the first, smaller step: a standalone browser prototype with a real CSS pixel-art fly, words appearing in the black area, animated activity, and working Start/Pause/Reset controls.

Open `web/index.html` in a browser. For iPhone, hosting this file on GitHub Pages is preferable to opening it from the Files app.

Scientific note: this version is a computational demo and does not yet run neural dynamics through the real fly connectome.
